# Qwen3-TTS Android ARM64 build kit

This package combines the public Android reference app with the native `qwen3-tts.cpp`
source tree. It is intended as a **build/compatibility reference** before integrating
the engine into the existing CORVUS-S application.

## What is included

- `app/`: the author's standalone Android reference app and Kotlin/JNI integration.
- `app/src/main/cpp/CMakeLists.txt`: Android native build configuration.
- `external/qwen3-tts.cpp/`: native Qwen3-TTS C++ sources from the supplied source archive.
- `.github/workflows/android-arm64.yml`: GitHub Actions workflow to build an ARM64 APK.
- GGML is fetched by the workflow from its official public repository at build time.

## Build in GitHub Actions

1. Create an empty GitHub repository.
2. Upload the **contents** of this folder to its root (not the enclosing folder).
3. Open the repository's **Actions** tab.
4. If GitHub asks, enable Actions.
5. Run **Build Qwen3 TTS Android (ARM64)** with **Run workflow**.
6. When it completes, open the run and download the artifact named
   `qwen3-tts-android-arm64-debug`.

## Important limitations

- This builds the author's standalone Qwen3-TTS reference app as a compatibility test.
  It does **not** modify or build CORVUS-S.
- The workflow fetches the current `ggml-org/ggml` default branch at build time.
  This dependency has not been compiled or tested in this environment; if upstream
  interfaces have changed, the build may need a pinned compatible GGML revision.
- The resulting APK is not yet the final CORVUS-S integration.
- Model weights are not included. The reference app downloads its model files on device.
- The native build targets `arm64-v8a`; it is not intended for x86 emulators.

## Upstream sources

- Android reference: https://github.com/Danmoreng/qwen3-tts-android
- Native engine: https://github.com/Danmoreng/qwen3-tts.cpp
- GGML: https://github.com/ggml-org/ggml

The upstream Android project is MIT-licensed. The native engine and GGML retain their
respective upstream license files in the included source trees.
